# 0.6.0
- more alchemy 
- settings fix for Adventure Deck
- settings for chase and chase macro can have a default
- TODO falling damage macro
- docs

# 0.5.9
- more alchemy

# 0.5.8
- api docs
- alchemy fix and improve

# 0.5.7
- alchemy docs

# 0.5.6
- alchemy

# 0.5.5
- adventure card renamed to Adventure Deck
- adventure card improved fix 2
- swade macros option to adventure deck
- docs

# 0.5.4
- adventure card improved fix

# 0.5.3
- adventure card improved by kristianserrano

# 0.5.2
- unshaken unstun improved
- adventure card
- docs
- api

# 0.5.1
- Spellbook Manager
- docs

# 0.5.0
- Equip-Unequip-Sets fix
- docs

# 0.4.9
- Equip-Unequip-Sets
- docs

# 0.4.8
- everyone + more reliable code for Coin Manager for Savage Pathfinder 
- boost-lower-trait reliable + chat message

# 0.4.7
- Coin Manager for Savage Pathfinder
- docs

# 0.4.6
- boost-lower-trait update and fix 
- bug reporter

# 0.4.5
- boost-lower-trait macro from @SirDiesalot#2922 
- AE Builder auto name fix
- AE Builder encumbrance steps

# 0.4.4
- AE Builder auto name fix

# 0.4.3
- AE Builder supports Skills
- Docs

# 0.4.2
- Feet To SWADE gui
- Images To Folder will create the folder for you
- Vehicle Maneuvers

# 0.4.1
- fear table fix

# 0.4.0
- fear table checks spirit
- api fatigue
- docs

# 0.3.9
v8.9 ok

# 0.3.8
- gm manager macro update
- docs
- deviation
- dependencies: warpgate and compendium-folders

# 0.3.7
- interlude

# 0.3.6
- shaken spend benny to unshaken
- Dramatic Tasks
- unstun
- docs

# 0.3.5
- Quick Combat is back!

# 0.3.4
- ImagesToFolder
- test with creative combat
- feet to swade macro
- docs

# 0.3.3
- sprawlrunners_slowburn_options update
- AE Builder update

# 0.3.2
- 2 scenes

# 0.3.1
- sprawlrunners_slowburn_options
- Character Summarizer penllawen 
- docs

# 0.3.0
- quick wait for you
- docs
- manager player update

# 0.2.9
- gang up rules link
- test macro
- support update
- docs
- mass battle whisper

# 0.2.8
- ae builder
- scene for social conflict

# 0.2.7
- healing can target
- support fixed
- Size/Scale Calculator update
- Power Point Management
- Player - Macro Manager
- Fear 

# 0.2.6
- size/scale macro updated
- token vision added
- update for docs

# 0.2.5
Chase scene fixed

# 0.2.4
- support added to player
- fear swade added to player
- api load macro from any compendium
- manager no longer reopen

# 0.2.3
- don't care about core star
- Unshaken fixed
- unstun added
- api improved
- grappling/push removed until fixed
- healing 

# 0.2.2
- healing wounds/fatigue ok
- support
- gm/everyday/swade manager
- api

# 0.2.1
- scene for chase

# 0.2.0
- healing fix
- API

# 0.1.9
- doc update

# 0.1.8
- LP Check only when equipped
- 3d measure
- better docs
- manager update

# 0.1.7
- Improved Adventure Generator macro for Deadlands
- compendium with macros are private by default
- docs

# 0.1.6
Auto update macros.

# 0.1.5
chase improved again 2 by kristianserrano

# 0.1.4
chase improved again by kristianserrano 

# 0.1.3
chase improved by kristianserrano

# 0.1.2
packs added

# 0.1.1
- chase small fix
- Sprawlrunners LP Check

# 0.1.0
- push fix

# 0.0.9
- push macro

# 0.0.8
- fix healing to detect wild card ok
- fix grappling (wild detect) ok
- fix mass battle (wild select) ok
- Survival Guide

# 0.0.7
raise calculator

# 0.0.6
small fix for release

# 0.0.5
Macro manager + size/scale

# 0.0.4
First