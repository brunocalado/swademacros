            game.cub.addCondition("Incapacitated");
