
/*
select 1d6+1 - try to ready height
max 10d6 + 10
Soft grounds (foot):

OUTPUT water:

Falling damage is 1d6 + 1 per 2″ (4 yards), to
a maximum of 10d6 + 10.

Snow: Particularly soft ground, such as
very deep snow, acts as a cushion. Every foot
of soft snow reduces damage 1 point.

Water: A successful Athletics roll halves
damage into reasonably deep water at heights
of 10″ (20 yards) or less. A raise negates the
damage entirely. Those who fall into water
from heights greater than 20 yards take
damage as if they’d hit solid earth.
*/

