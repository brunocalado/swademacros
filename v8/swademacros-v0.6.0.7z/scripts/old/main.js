let _macroHelper;

Hooks.on("canvasReady", () => {  
  _macroHelper = new macroHelper();
});